﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace inventory.Model
{
    public class inventoryContext : DbContext
    {
        public inventoryContext(DbContextOptions<inventoryContext> options)
            : base(options)
        { }

        public DbSet<item> items { get; set; }
        
    }

    public class item
    {
        public int id { set; get; }
        public string name { set; get; }
        public string description { set; get; }
        public int unit_price { set; get; }
        public int no_of_unit_available { set; get; }
    }
}
