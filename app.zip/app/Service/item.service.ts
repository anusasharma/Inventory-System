import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Item } from '../Model/item.model';

@Injectable({
  providedIn: 'root'
})
export class ItemService {

  private headers: HttpHeaders;

  constructor(private http:HttpClient) {
    this.headers = new HttpHeaders({'Content-Type':'application/json, charser=utf-8'});
   }

   private itemUrl = 'https://localhost:44362/api/item/';

   getAll(){
    return this.http.get(this.itemUrl, {headers : this.headers});
  }

  get(id){
    return this.http.get(this.itemUrl+id,{headers : this.headers});
  }

  create(data){
    return this.http.post(this.itemUrl,data, {headers : this.headers});
  }

  drop(id){
    return this.http.delete(this.itemUrl+id, {headers : this.headers});
  }

  edit(data:Item, id:number){
    return this.http.put<Item>(this.itemUrl+id,data);
  }
}
