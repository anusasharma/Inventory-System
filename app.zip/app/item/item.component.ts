import { Component, OnInit } from '@angular/core';
import { Item } from '../Model/item.model';
import { ItemService } from '../Service/item.service';
import { Validators, FormBuilder, FormGroup, FormControl, FormGroupDirective } from '@angular/forms';


@Component({
  selector: 'app-item',
  templateUrl: './item.component.html',
  styleUrls: ['./item.component.css']
})
export class ItemComponent implements OnInit {

  items: Array<any> = [];// items are saved in an array
  itemsForSearch: Array<any>;//items can be searched in an array
  nameWithId: Map<number, string> = new Map<number, string>();// to make the name in lowercase
  itemObj: Item = new Item;   //creating an object to edit
  EditData: Object;           //to edit
  ItemName: string;           //to search item by name
  ItemDes: string;            //to search item by description
  itemSearch: boolean;        //to search item
  showTable: boolean;         //to show the details in a table
  Deleteid: number;           //to delete
  SearchItemNotFound = false; //If the item is not there       
  submitted = false;          //submit function
  item: any;
  mesaage = '';
  messageColor = 'lightgray'

  constructor(public itemService: ItemService,
    private _fb: FormBuilder) { }

  public itemAddModalForm: FormGroup;


  ngOnInit() {

    this.EditData = {
      id: 0,
      Title: 'Add new item'
    }

    this.getAllItems();
    this.itemAddModalForm = this._fb.group({
      name: ['', Validators.required],
      description: [''],
      unitprice: [0, Validators.min(1)],
      noofunits: [0, Validators.min(1)]
    },
      // { validator: [this.itemAddValidationName, this.itemAddValidationUnitPrice, 
      //   this.itemAddValidationNoOfUnits] }
        );
  }

  get f() { return this.itemAddModalForm.controls; }

  deleteConfirmation(id) { //for getting a confirmation message
    this.Deleteid = id;
  }

  getAllItems() { //getting all the items
    this.items = []
    this.itemService.getAll().subscribe((data: any) => {
      data.forEach(element => {
        this.items.push(element);
        
      });
      var stringArray = this.items
      this.items = stringArray.sort((a, b) => 0 - (a.name > b.name ? -1 : 1));
      this.itemsForSearch = data;

    });

  }

  submit() {  //after adding a new item
    this.submitted = true;
    this.itemObj   = new Item();
    this.itemObj.name                   = this.itemAddModalForm.get('name').value;
    this.itemObj.description            = this.itemAddModalForm.get('description').value;
    this.itemObj.unit_price             = this.itemAddModalForm.get('unitprice').value;
    this.itemObj.no_of_unit_available   = this.itemAddModalForm.get('noofunits').value;

    if ((this.itemAddModalForm.hasError('name') || this.itemAddModalForm.hasError('unitprice') || this.itemAddModalForm.hasError('noofunits'))) {

    }

    else {
      if (!this.itemObj.description) {
        this.itemObj.description = 'No Description'
      }
      if (this.EditData['id'] == 0) {
          this.itemService.create(this.itemObj).subscribe((data: any) => {
          this.getAllItems();
        });

        this.mesaage = 'Added'
        this.messageColor = '#a5ffa5'

        setTimeout(() => {
          this.mesaage = ''
        }, 3000);
      }
      else {
        this.itemObj.id = this.EditData['id'];
        this.itemService.edit(this.itemObj, this.EditData['id']).subscribe((data: any) => {
          this.getAllItems();
        });
        this.EditData['id'] = 0;
        this.mesaage = 'Edited'
        this.messageColor = '#ffff81'

        setTimeout(() => {
          this.mesaage = ''
        }, 3000);
      }
      this.closeModel()
    }

  }

  search() { //To search items
    var tempArray = []
    this.itemsForSearch.forEach(element => {
      if (element.name.toLowerCase().includes(this.ItemName.toLowerCase())) {
        tempArray.push(element)
      }
    });
    this.itemsForSearch.forEach(element => {
      if (element.description.toLowerCase().includes(this.ItemName.toLowerCase())) {
        if (tempArray.find(data => data.id == element.id)) {

        }
        else {
          tempArray.push(element)
        }
      }
    });
    if (tempArray.length == 0) {
      this.SearchItemNotFound = true;
      this.itemSearch = true;
    }

    else {
      this.items = [];
      this.items = tempArray;
      
      this.itemSearch = true;
      this.showTable = true;
    }

    if (this.ItemName == '') {
      this.showAllItems()
    }
  }

  showAllItems() {  //to get all the items after searching an item
    this.getAllItems();
    this.itemSearch = false;
    this.SearchItemNotFound = false
  }

  delete(id) {    //delete an item
    this.itemService.drop(id).subscribe((data: any) => {
      this.getAllItems();
    });

    this.mesaage = 'Deleted'
    this.messageColor = '#ffb9b9'


    setTimeout(() => {
      this.mesaage = ''
    }, 3000);
  }

  // itemAddValidationName(group: FormGroup) {   //Validation for the add function for name
  //   const names = group.controls.name.value;
  //   if (names == '') {
  //     return { name: true };
  //   }

  // }

  // itemAddValidationUnitPrice(group: FormGroup) {    //Validation for the add function for unit price
  //   const unit_prices = group.controls.unitprice.value;
  //   if (unit_prices < 1) {
  //     return { unitprice: true };
  //   }
  // }

  // itemAddValidationNoOfUnits(group: FormGroup) {  //Validation for the add function for no of unit available
  //   const no_of_unit_availables = group.controls.noofunits.value;
  //   if (no_of_unit_availables < 1) {
  //     return { noofunits: true };
  //   }

  // }

  Edit(id) {        //edit an item
    this.EditData['id'] = id;
    this.EditData['Title'] = 'Edit item';
    var gotById = this.items.find(item => item.id === id)

    this.itemAddModalForm.controls['name'].setValue(gotById.name);
    this.itemAddModalForm.controls['description'].setValue(gotById.description);
    this.itemAddModalForm.controls['unitprice'].setValue(gotById.unit_price);
    this.itemAddModalForm.controls['noofunits'].setValue(gotById.no_of_unit_available);
  }


  closeModel() {    //to close the modal
    this.itemAddModalForm.controls['name'].setValue('');
    this.itemAddModalForm.controls['description'].setValue('');
    this.itemAddModalForm.controls['unitprice'].setValue(0);
    this.itemAddModalForm.controls['noofunits'].setValue(0);
    this.submitted = false;
    this.EditData['Title'] = 'Add new item';
    this.EditData['id'] = 0;
  }

  showTableFtn() {        //to show the whole items in a table
    if (this.showTable) {
      this.showTable = false;
    }
    else {
      this.showTable = true;
    }
  }

}
