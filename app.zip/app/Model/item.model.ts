export class Item {
    id:number;
    name:string;
    description:string;
    unit_price:number;
    no_of_unit_available:number;
}
